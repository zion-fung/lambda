## lambda (Slack bot made in aws lambda)

### Installation
- Make a lambda function in AWS in node.js
  - BOT_TOKEN (env variable) should be "Bearer " prepended to your Bot User Oauth Token
- Upload the code by manually creating a zip or calling upload.sh
- Deploy an API Gateway that calls the lambda function that you created
- Make a slack app with a bot user and use the url from the API Gateway as the Event target
- Invite slack app into your channel

### Pre-installation
- Run npm install
- Make a settings.json in the mongo folder
```
{
    "mongoConfig": {
      "serverUrl": "",
      "database": ""
    }
}
```

### TODO
- Oauth Authentication for other workspace installation
