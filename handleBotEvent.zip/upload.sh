rm handleBotEvent.zip
zip -r handleBotEvent.zip *
aws lambda update-function-code --function-name handleBotEvent --zip-file fileb://./handleBotEvent.zip --region us-east-1