const fetch = require("node-fetch");
const Headers = require("node-fetch").Headers;
const verificationUrl = "https://slack.com/api/oauth.access"
const ejs = require("ejs");

exports.handler = async (event) => {
    const params = event["body"]["params"]["querystring"]
    if(!params["code"]) {
        return ""
    }
    const data = {form: {
        client_id: process.env.SLACK_CLIENT_ID,
        client_secret: process.env.SLACK_CLIENT_SECRET,
        code: params["code"]
    }}
    const response = await fetch(verificationUrl, {
        method: "POST",
        body: JSON.stringify(data),
        headers: new Headers({"Content-Type": "	application/x-www-form-urlencoded"})
    })
    if(response["ok"] === true) {
        return ejs.renderFile("./auth.ejs", {
            message: "Success"
        })
    } else {
        return ejs.renderFile("./auth.ejs", {
            message: "Failed to Authenticate"
        })
    }
};
